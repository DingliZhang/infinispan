/**
 * Hot Rod client annotations.
 *
 * @public
 */
package org.infinispan.client.hotrod.annotation;
