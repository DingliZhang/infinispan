/**
 * HotRod Client Exceptions
 *
 * @public
 */
package org.infinispan.client.hotrod.exceptions;
