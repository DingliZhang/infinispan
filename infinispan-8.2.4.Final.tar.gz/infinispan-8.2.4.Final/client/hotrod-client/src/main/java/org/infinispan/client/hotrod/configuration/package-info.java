/**
 * HotRod Client Configuration API
 *
 * @public
 */
package org.infinispan.client.hotrod.configuration;
