package org.infinispan.cli.interpreter.result;

public interface Result {
   String getResult();
}
