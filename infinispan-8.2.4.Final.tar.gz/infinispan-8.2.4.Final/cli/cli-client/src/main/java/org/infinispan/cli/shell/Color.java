package org.infinispan.cli.shell;

/**
 * @author Mike Brock .
 */
public enum Color
{
   NONE, BLACK, BLUE, CYAN, GREEN, MAGENTA, RED, YELLOW,  WHITE, BOLD, ITALIC
}
