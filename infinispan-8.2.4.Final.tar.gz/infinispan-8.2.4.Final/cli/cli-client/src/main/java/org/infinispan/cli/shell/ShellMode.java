package org.infinispan.cli.shell;

public enum ShellMode {
   INTERACTIVE,
   BATCH
}
