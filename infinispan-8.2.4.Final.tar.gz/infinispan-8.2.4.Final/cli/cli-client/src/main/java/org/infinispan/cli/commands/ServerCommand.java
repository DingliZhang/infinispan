package org.infinispan.cli.commands;

public interface ServerCommand extends Command {
   int nesting();
}
