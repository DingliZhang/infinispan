Infinispan CDI support common module
====================================

This module is not meant to be used individually. It only contains common to Remote and Embedded classes which are attached as sources to those modules.
