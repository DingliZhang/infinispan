/**
 * This package contains the adapters making the bridge between Infinispan cache events and CDI.
 */
package org.infinispan.cdi.event.cache;
