/**
 * This package contains the adapters making the bridge between Infinispan cache manager events and CDI.
 */
package org.infinispan.cdi.event.cachemanager;
